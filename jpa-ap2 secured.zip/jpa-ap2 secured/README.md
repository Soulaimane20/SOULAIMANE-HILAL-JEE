#Part 1- Spring Security 6 - InMemoryAuthentication

Activite 4:

![log](https://user-images.githubusercontent.com/94021293/234411541-47e47c5b-26f0-4b4a-bc90-9db23ab48a23.png)

![indexAdmin](https://user-images.githubusercontent.com/94021293/234411552-b4ca5a59-a0f9-4788-b16f-7374b6f2cff8.png)

![edit](https://user-images.githubusercontent.com/94021293/234411566-4b973cd9-e095-4b73-9a6c-aca2378f6c89.png)

![edited](https://user-images.githubusercontent.com/94021293/234411587-f770ce92-01f8-4c81-9ba7-5d36e2d1a6ac.png)

![securityConfig](https://user-images.githubusercontent.com/94021293/234411600-273cd167-75f7-4ecc-8320-8c1f658c2d30.png)

![passencoder](https://user-images.githubusercontent.com/94021293/234411622-ed27b2af-bd93-4af4-8b11-8ff9ec4f5f03.png)


![formLOGIN](https://user-images.githubusercontent.com/94021293/234439442-edab2d0a-5e1d-4b51-92c6-3fe5eaefb4cb.png)

![userSuppnotAuth](https://user-images.githubusercontent.com/94021293/234439447-06c503b3-6274-4fc1-b197-4fed7ad446f7.png)
