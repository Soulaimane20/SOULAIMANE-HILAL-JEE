package ma.emsi.ebankingbackend.enums;

public enum OperationType {
    DEBIT,CREDIT
}
