package ma.emsi.ebankingbackend.enums;

public enum AccountStatus {
    CREATED,SUSPENDED,ACTIVATED
}
